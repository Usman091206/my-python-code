print("hello world")
print(5)
print("usman khan", 5)
print(30 * 20)
print("baba black sheep have you any wool yes sir yes sir three bag full")
# what is comments

# ghefguyqhfufhuiqehfkhqrfvbiulgg
'''
hjerjgjkdsgkwhgbwjekhrbwkjrebnijwernbgjeribnwkjebn
rewjhguwergkrqewg
gwuekgbkweghlqergeqrguyh
'''
# escape sequence characters
print("usman' khan", 5, 6, 7, sep="~", end="009\n usman khan  abbasi")
print('usman khan')
print("hello  world",
      54 * 80,
      5,
      7,
      sep="~",
      end="998877\n hypertext markup languages,33*60")
print("usman khan", 54 * 80)

# variables AND data types
a = 156256452758167848
print(a)
# b="usman khan",6784728
# print(b)
a = 1
b = "usman khan"
c = True
d = None
e = 1.676832769875
f = 8, 7
print("the type of a is", type(a))
print("the type of b is", type(b))
print("the type of c is", type(c))
print("the type of d is", type(d))
print("the type of e is", type(e))
print("the type of f is", type(f))
k = 1 + 2
print(k)
print(1 + 2)
print(1 - 2)
print(1 * 2)
print(1 / 2)
print(1 // 2)
print(1 % 2)
print(1**2)
a = 5
b = 8
print("the value of", 5, "+", 8, "is:", a + b)
print("the value of", 5, "-", 8, "is:", a - b)
print("the value of", 5, "*", 8, "is:", a * b)
print("the value of", 5, "/", 8, "is:", a / b)
print("the value of", 5, "//", 8, "is:", a // b)
print("the value of", 5, "%", 8, "is:", a % b)
print("the value of", 5, "**", 8, "is:", a**b)

# explicit typecasting
a = "5"
b = "9"
print(int(a) + int(b))

# implicit typecasting
a = 15.0
b = 7
print(a + b)

# what is userinput
# a=input("enter your name")
# print("my name is",a)

# string in python/indexing
name = "usman khan"
print(name[0])
print(name[1])
print(name[2])
print(name[3])
print(name[4])
print(name[5])
print(name[6])
print(name[7])
print(name[8])
print(name[9])
for character in name:
  print(character)

  # string slicing
name = "harry potter"
print(len(name))
print(name[4:10])

# string method
m = "usman,,,, abbasi ''''''' khan???/"
print(m.upper())
print(m.lower())
print(m.rstrip("/"))
print(m.replace("usman", "abbasi"))
print(m.split())
blogheading = "introductioN to jS"
print(blogheading.capitalize())
str1 = "welcome to to to to the console,,,"
print(len(str1))
print(str1.center(60))
print(str1.index("so"))
print(str1.count("to"))
print(str1.endswith(","))
print(str1.find("on"))
str2 = "usman"
print(str2.isalnum())
print(str2.isalpha())
str3 = "PYTHON IS AN INTERPRETED LANGUAGE"
print(str3.islower())
print(str3.isupper())
print(str3.isprintable())
str4 = ("    ")
print(str4.isspace())
str5 = "world health organization"
print(str5.istitle())
print(str5.title())
print(str5.swapcase())

# now we study on if _elif or else conditional statements
a = 24
# conditional opeartors
# >,<,>=,<=,==,!=
print(a > 24)
print(a < 24)
print(a >=24)
print(a <=24)
print(a ==24)
print(a !=24)
if (a>24):
  print("you can drive")
  print("yes") 
else:
  print("you cannot drive")
  print("no")
appleprice=10
budget=200
if(budget-appleprice>200):
  print("akexa,add 1 kg apple to the cart")
elif(budget-appleprice>210):  
 print("its ok you can buy")
if(budget-appleprice>160):
 print("its ok you can buy please")
else:
  print("alexa,do not add apple to the cart")
num=70
if(num<0):
    print("number is negative")
elif(num==0):
    print("number is zero")
elif(num<=0):
    print("number is special")
else:
    print("number is positive")
num=18
if(num<0):
 print("number is negative")
elif(num==0):
    print("number is special")
elif(num>0):
    print("number is enhance")
if(num<=0):
    print("number is obvious")
elif(num==0):
    print("number is none")
else:
    print("number is genious")
if(num==0):
    print("number is precious")
else:
 print("number is positive")
     
# exercise
 import time

timestamp = time.strftime('%H:%M:%S')
print(timestamp)
timestamp = time.strftime('%H:')
print(timestamp)
timestamp = time.strftime('%M:')
print(timestamp)
timestamp = time.strftime('%S:')
print(timestamp)

# match case statement
x=10
match x:
 case 0:
     print("x is zeo")
 case 3:
    print("x is not zero")
 case 7:
     print("x is yes zero")
 case _ if x!=10:
    print("x is not correct")
 case _ if x>10:
    print("x is not authentic")
 case _: 
   print("x is fi authentic")

# what is for loop
name="abhishek"
for a in name:
    print(a)
colors=["red", "green", "blue", "yellow"] 
for colors in colors:
    print(colors)
    for i in colors:
        print(i)
  
